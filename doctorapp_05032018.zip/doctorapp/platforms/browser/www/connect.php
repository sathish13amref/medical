 
 <?php

 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $dbname = "medical";
 
 // Create connection
 $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname) or die($conn->connect_error);
 
 

 
?>